﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DingDingSDK
{
    public class Vars
    {
        public static String TO_USER = "";
        public static String TO_PARTY = "";
        public static String AGENT_ID = "";
        public static String SENDER = "";
        public static String CID = "";
    }
}
