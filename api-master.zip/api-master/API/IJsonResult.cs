﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API
{
    /// <summary>
    /// JsonResult标识接口，标识该类是一个JSON Result对象
    /// </summary>
    public interface IJsonResult
    {
    }
}
