﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API.Qy
{
    /// <summary>
    /// 
    /// </summary>
    public class ConvertOpenIdToUserIdResult : APIJsonResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string userid { get; set; }
    }
}
