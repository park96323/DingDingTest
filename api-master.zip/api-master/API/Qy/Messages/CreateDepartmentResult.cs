﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Qy
{
    public class CreateDepartmentResult : APIJsonResult
    {
        /// <summary>
        /// 
        /// </summary>
        public int id { get; set; }
    }
}