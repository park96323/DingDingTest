﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API.Qy
{
    /// <summary>
    /// 
    /// </summary>
    public class ConvertUserIdToOpenIdResult : APIJsonResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string openid { get; set; }
    }
}
