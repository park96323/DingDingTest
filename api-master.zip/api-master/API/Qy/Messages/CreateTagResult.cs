﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Qy
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateTagResult : APIJsonResult
    {
        public int tagid { get; set; }
    }
}