﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API
{
    public enum APIType
    {
        /// <summary>
        /// 
        /// </summary>
        Weixin = 0,
        /// <summary>
        /// 
        /// </summary>
        Dingtalk = 1
    }
}
