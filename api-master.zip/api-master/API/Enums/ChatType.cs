﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API
{
    /// <summary>
    /// 
    /// </summary>
    public enum ChatType
    {
        /// <summary>
        /// 单聊
        /// </summary>
        single,
        /// <summary>
        /// 群聊
        /// </summary>
        group,
    }

}
