﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API.Mp.Open
{
    /// <summary>
    /// 公众号授权给开发者的权限集列表
    /// </summary>
    public class funcscope_category
    {
        /// <summary>
        /// 
        /// </summary>
        public int id { get; set; }
    }
}
